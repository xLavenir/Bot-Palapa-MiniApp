import delay from "delay";

async function signIn() {
  const api = await fetch(
    "https://b.bittime.com/exchange-web-gateway/tg-mini-app/login?appName=Netscape&appCodeName=Mozilla&appVersion=5.0+(iPhone%3B+CPU+iPhone+OS+16_6+like+Mac+OS+X)+AppleWebKit%2F605.1.15+(KHTML,+like+Gecko)+Version%2F16.6+Mobile%2F15E148+Safari%2F604.1&userAgent=Mozilla%2F5.0+(iPhone%3B+CPU+iPhone+OS+16_6+like+Mac+OS+X)+AppleWebKit%2F605.1.15+(KHTML,+like+Gecko)+Version%2F16.6+Mobile%2F15E148+Safari%2F604.1&cookieEnabled=true&platform=Win32&userLanguage=id-ID&vendor=Google+Inc.&onLine=true&product=Gecko&productSub=20030107&mimeTypesLen=2&pluginsLen=5&javaEnbled=false&windowScreenWidth=1920&windowScreenHeight=1080&windowColorDepth=24",
    {
      method: "POST",
      headers: {
        accept: "application/json, text/plain, */*",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "content-type": "application/json;charset=UTF-8",
        origin: "https://palapaminiapp.bittime.com",
        priority: "u=1, i",
        referer: "https://palapaminiapp.bittime.com/",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent":
          "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
      },
      body: JSON.stringify({
        initData:
          "user=%7B%22id%22%3A1179308441%2C%22first_name%22%3A%22Beluga%20%F0%9F%92%A0%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22belugahimself%22%2C%22language_code%22%3A%22en%22%7D&chat_instance=-9119589948386969435&chat_type=channel&start_param=WQWZVEAWH&auth_date=1730361439&hash=e64f832c2d00ec6e2352c4fd9768d3ebb3830b7dee7f5172a8b0c6e64361688b",
        username: "belugahimself",
        lang: "en",
        invitedCode: "WQWZVEAWH",
      }),
    }
  );
  const response = await api.json();
  return response;
}

async function shakeGame() {
  const apiShake = await fetch(
    "https://b.bittime.com/exchange-web-gateway/tg-mini-app/shake?appName=Netscape&appCodeName=Mozilla&appVersion=5.0+(iPhone%3B+CPU+iPhone+OS+16_6+like+Mac+OS+X)+AppleWebKit%2F605.1.15+(KHTML%2C+like+Gecko)+Version%2F16.6+Mobile%2F15E148+Safari%2F604.1&userAgent=Mozilla%2F5.0+(iPhone%3B+CPU+iPhone+OS+16_6+like+Mac+OS+X)+AppleWebKit%2F605.1.15+(KHTML%2C+like+Gecko)+Version%2F16.6+Mobile%2F15E148+Safari%2F604.1&cookieEnabled=true&platform=Win32&userLanguage=id-ID&vendor=Google+Inc.&onLine=true&product=Gecko&productSub=20030107&mimeTypesLen=2&pluginsLen=5&javaEnbled=false&windowScreenWidth=1920&windowScreenHeight=1080&windowColorDepth=24",
    {
      method: "POST",
      headers: {
        accept: "application/json, text/plain, */*",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "content-type": "application/json;charset=UTF-8",
        origin: "https://palapaminiapp.bittime.com",
        priority: "u=1, i",
        referer: "https://palapaminiapp.bittime.com/",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent":
          "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
        Cookie:
          "acw_tc=9581d30717303600643257709e1aeead8e88cd746948882c58dea6fd549d41",
      },
      body: JSON.stringify({
        initData:
          "user=%7B%22id%22%3A1179308441%2C%22first_name%22%3A%22Beluga%20%F0%9F%92%A0%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22belugahimself%22%2C%22language_code%22%3A%22en%22%7D&chat_instance=-9119589948386969435&chat_type=channel&start_param=WQWZVEAWH&auth_date=1730359632&hash=8ae59c5cc9fd73d855ff697ca9b244fa4a0b4556d58ccc0bd9b4165ea29a10bc",
        uid: 1179308441,
        shakeNum: 25,
        coin: 25,
      }),
    }
  );
  const response2 = await apiShake.json();
  return response2;
}

async function checkAndShake() {
  try {
    // Login dan dapatkan data
    const login = await signIn();
    const energyRemaining = login.data.energy;
    const coin = login.data.coin;
    const newLevel = login.data.level;

    const output = `Energy: ${energyRemaining}, Coin: ${coin}, New Level: ${newLevel}`;
    console.log(output);

    const shake = Math.round(energyRemaining / 25);
    console.log(`Jumlah shake yang tersedia: ${shake}`);

    if (shake > 0) {
      let i = 0;
      while (i < shake) {
        try {
          console.log("Shaking ke ", i + 1);
          await shakeGame();
          await delay(2000);
          i++;
        } catch (error) {
          console.log("Error saat melakukan shake:", error);
          await delay(5000); // Deiay Jika Error
        }
      }
    }

    // Tunggu 10 menit sebelum pengecekan berikutnya
    console.log("Menunggu 10 menit sebelum pengecekan berikutnya...");
    await delay(600000);

    // Panggil fungsi ini lagi untuk loop berkelanjutan
    checkAndShake();
  } catch (error) {
    console.log("Error pada proses pengecekan:", error);
    // Jika terjadi error, tunggu 1 menit sebelum mencoba lagi
    await delay(60000);
    checkAndShake();
  }
}

// Mulai proses
console.log("Memulai auto shake...");
checkAndShake();
